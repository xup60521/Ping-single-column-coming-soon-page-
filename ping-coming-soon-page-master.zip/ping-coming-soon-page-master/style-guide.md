# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 These are just the design sizes. Ensure content is responsive and meets WCAG requirements by testing the full range of screen sizes from 320px to large screens.

## Colors

### Primary

- Blue: hsl(223, 87%, 63%)

### Secondary

- Pale Blue: hsl(223, 100%, 88%)
- Light Red: hsl(354, 100%, 66%)

### Neutral

- Gray: hsl(0, 0%, 59%)
- Very Dark Blue: hsl(209, 33%, 12%)

## Typography

### Body Copy

- Font size: 20px

### Fonts

- Family: [Libre Franklin](https://fonts.google.com/specimen/Libre+Franklin)
- Weights: 300, 600, 700

## Icons

For the social icons, you can use a font icon library. Some suggestions can be found below:

- [Font Awesome](https://fontawesome.com)
- [IcoMoon](https://icomoon.io)
- [Ionicons](https://ionicons.com)

> 💎 [Upgrade to Pro](https://www.frontendmentor.io/pro?ref=style-guide) for design file access to see all design details and get hands-on experience using a professional workflow with tools like Figma.
